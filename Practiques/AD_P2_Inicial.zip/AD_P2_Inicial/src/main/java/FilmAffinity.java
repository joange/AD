import lombok.*;

import java.io.Serializable;
import java.util.ArrayList;

@Data
@AllArgsConstructor
@ToString@EqualsAndHashCode
@NoArgsConstructor
public class FilmAffinity implements Serializable {

    private static double serialVersionUID = 17L;

    private String id;
    private String titulo;
    private int anyo;
    private String pais;
    private ArrayList<String> actores;
    private ArrayList<String> generos;
    private String sinopsis;
    private float nota;

}

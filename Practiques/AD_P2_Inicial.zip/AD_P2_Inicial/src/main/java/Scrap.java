import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;

public class Scrap {

    private Logger log;

    public String getUserAgent() {
        String[] userAgents = {
                // Windows + Chrome
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",

                // Windows + Firefox
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/118.0",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0",

                // Windows + Edge
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36 Edg/118.0.2088.46",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.47",

                // macOS + Chrome
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",

                // macOS + Safari
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15",

                // macOS + Firefox
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/118.0",

                // Linux + Chrome
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",

                // Linux + Firefox
                "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/118.0",

                // Android + Chrome
                "Mozilla/5.0 (Linux; Android 13; SM-A536B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
                "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36",

                // Android + Samsung Browser
                "Mozilla/5.0 (Linux; Android 13; SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/22.0 Chrome/111.0.5563.116 Mobile Safari/537.36",

                // iOS (iPhone) + Safari
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
                "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",

                // iOS (iPad) + Safari
                "Mozilla/5.0 (iPad; CPU OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",

                // Altres dispositius mòbils
                "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
                "Mozilla/5.0 (Linux; Android 11; Redmi Note 9S) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
                "Mozilla/5.0 (Linux; Android 10; HD1913) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36"
        };

        int randomIndex = (int) (Math.random() * System.currentTimeMillis()) % userAgents.length;
        return userAgents[randomIndex];
    }

    public ArrayList<FilmAffinity> elsFilms;

    public Scrap() {
        log = LoggerFactory.getLogger(Scrap.class);
        elsFilms = new ArrayList<>();
    }

    /**
     * Aquesta funció s'encarrega de a partor de una pàgina que conte la inforamció
     * de un film, crear el objecte FilmAffinity per a guardar la informaicó
     *
     * @param fileName
     */
    public void parseHTML(String fileName) {

        String html = null;
        try {
            html = Files.readString(Path.of(fileName));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        Document doc = Jsoup.parse(html);

        Elements movies = doc.select("li.grid-item");
        for (Element movie : movies) {
            try {
                Element enllaç = movie.getElementsByTag("a").get(0);
                String title = enllaç.attr("title");
                String link = enllaç.attr("href");

                System.out.println("Title: " + title + ". Link: " + link);
                scrapFilm(link);
            } catch (IndexOutOfBoundsException ex) {
                System.out.println("Falten dades. Continuem");
            }
        }
    }

    /**
     *
     * @param url      web on feem el scrap (si no s'ha fet ja)
     * @param fileName on guardarem el scrap, per reaprofitar
     * @return el Document per processar
     */
    public Document scrapWebpage(String url, String fileName) {

        log.info("Carregant el navegador Chrome en mode headless");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new");
        options.addArguments("--user-agent=" + getUserAgent());
        log.info("Chrome carregat!");
        WebDriver driver = new ChromeDriver(options);
        String pageSource = "";

        log.info("Iniciant connexió amb Selenium a " + url);

        Document doc = null;
        try {
            // 1. El navegador controlat per Selenium navega a la URL
            driver.get(url);

            log.info("Connexió correcta. Llegint informació...");
            // Espera un parell de segons perquè s'executi qualsevol JavaScript
            Thread.sleep(10000);

            // 2. Un cop la pàgina està carregada, obtenim l'HTML resultant
            pageSource = driver.getPageSource();

            // guardar en arxiu HTML
            try {
                Files.writeString(Path.of(fileName), pageSource);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        } catch (InterruptedException e) {
            log.info("Connexió fallida");
            e.printStackTrace();
        } finally {
            // 4. Molt important: tanca el navegador quan acabis
            driver.quit();
        }

        return Jsoup.parse(pageSource);

    }


    /**
     * Aquesta funció realitza el scrap de un film passat com a argument.
     * Si aquesta film està en local simpleement processa el html, per evitar
     * descarregues addicional
     *
     * @param link de l'estil href="https://m.filmaffinity.com/es/film942655.html
     */
    public void scrapFilm(String link) {

        Document doc;
        String idFilm = link.substring(link.lastIndexOf("film") + 4, link.lastIndexOf(".html"));
        log.info("ID del film: " + idFilm);

        String fileName = "src/main/resources/film" + idFilm + ".html";
        File file = new File(fileName);
        if (file.exists()) {
            try {
                doc = Jsoup.parse(file);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            doc = scrapWebpage(link, fileName);
        }

        Element movie_info = doc.getElementsByClass("movie-info").get(0);
        Element info = movie_info.getElementsByTag("dl").get(0);
        // recuperem les etiquetes dt
        Elements dt = info.getElementsByTag("dt");

        String titol = "", any = "", pais = "", reparto = "", sinopsis = "", genero = "";
        //recorreguem les etiquetes dt
        for (Element d : dt) {
            String camp = d.text();
            Element dd = d.nextElementSibling();

            switch (camp) {
                case "Título original:":
                    titol = dd.text();
                    break;
                case "Año / País:":
                    any = dd.text().split("/")[0].trim();
                    pais = dd.text().split("/")[1].trim();
                    break;
                case "País":
                    pais = dd.text();
                    break;
                case "Género":
                    Elements generos = dd.getElementsByTag("a");
                    for (Element g : generos) {
                        genero += g.text() + ", ";
                    }
                    //quitar última coma;
                    try {
                        genero = genero.substring(0, genero.length() - 2);
                    } catch (StringIndexOutOfBoundsException ex) {
                        log.warn("No s'ha pogut recuperar el valor del repartiment");
                    }
                    break;
                case "Reparto":
                    Elements actors = dd.getElementsByTag("a");
                    reparto = "";
                    for (Element actor : actors) {
                        reparto += actor.text() + ", ";
                    }
                    //quitar última coma;
                    try {
                        reparto = reparto.substring(0, reparto.length() - 2);
                    } catch (StringIndexOutOfBoundsException ex) {
                        log.warn("No s'ha pogut recuperar el valor del repartiment");
                    }
                    break;
                case "Sinopsis":
                    sinopsis = dd.text();
                    break;
            }

        }

        float valoracio = -1.0f; // això vol dir sense valoració
        try {
            valoracio = Float.parseFloat(doc.select("div.avgrat-box.font-lg.in-block").text().replace(",","."));
        } catch (NullPointerException ex) {
            log.warn("No s'ha pogut recuperar la valor de la valoració");
        }
        catch(NumberFormatException ex){
            log.warn("Format no reconegut");
        }

        FilmAffinity f = new FilmAffinity(
                idFilm,
                titol,
                Integer.parseInt(any),
                pais,
                new ArrayList<>(Arrays.asList(reparto.split(","))),
                new ArrayList<>(Arrays.asList(genero.split(","))),
                sinopsis,
                valoracio);
        log.info(f.toString());

        elsFilms.add(f);

    }


    /**
     * Aquest programa fa el scrap dels elements de la web de la variable
     * filmURL
     *
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) {

        Scrap app = new Scrap();

        String[] categories = {
                "cat_new_netflix",
                "cat_new_amazon_es",
                "cat_new_hbo_es",
                "cat_disneyplus",
                "cat_apple_tv_plus"
        };

        for (String categoria : categories) {
            String filmURL = "https://www.filmaffinity.com/es/" + categoria + ".html";
            String fileName = "src/main/resources/" + categoria + ".html";

            File f = new File(fileName);
            // si el fitxer no existeix o fa més de 24*7 hores de l'últim scrap (1 setmana)
            if (!f.exists() || (f.lastModified() + 3600000 * 24 * 7 < System.currentTimeMillis())) {
                app.log.info(("El fitxer no existeix o caducat."));
                app.scrapWebpage(filmURL, fileName);
            }

            app.parseHTML(fileName);
        }


        // Creem l'ObjectMapper
        ObjectMapper objectMapper = new ObjectMapper();

        // Convertim l'objecte a JSON
        String json = null;

        // string a pelo, sin formato
        try {
            json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(app.elsFilms);
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File("films.json"),app.elsFilms);
           // System.out.println(json);
        } catch (JsonProcessingException e) {
            app.log.error(e.getMessage());
        } catch (IOException e) {
            app.log.error(e.getMessage());
        }


    }

}

create table users (
    username char(20),
    password varchar(40) not null, 
    primary key (username)
);
